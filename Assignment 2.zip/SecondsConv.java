//I pledge my Honor that I have not cheated, and will not cheat, on this assignment Benjamin Allen U30786148

import java.util.Scanner;

public class SecondsConv
{
   public static void main(String[] args)
   {
   //Declare seconds, hours and minutes and a conversion rate between them
   int sec, hours, min;
   final int CONVRS = 60;
   
   //Import and initialize scanner
   Scanner scan = new Scanner (System.in);
   
   //Prompt user for input
   System.out.println ("Enter number of seconds: ");
   sec = scan.nextInt ();
   
   //Math
   min = sec / CONVRS;
   hours = min / CONVRS; 
   min = min % CONVRS;
   sec = sec - ((hours * (CONVRS * CONVRS)) + (min * CONVRS));
   
   //Output Math   
   System.out.println ("Number of Hours: " + hours
                    +  "\nNumber of Minutes: " + min
                    +  "\nNumber of Seconds: " + sec);
   }
}