//I pledge my Honor that I have not cheated, and will not cheat, on this assignment Benjamin Allen U30786148

import java.util.Scanner;

public class HerosMethodSqrt
{
   public static void main (String[] args)   
   {      

   Scanner scan = new Scanner (System.in);
   double n, a2;
   
   do 
   {
   System.out.println ("Enter a postivie number:");         
   n = scan.nextDouble(); 
   } while (n < 0);
   
   a2 = babSqrt(n);
   System.out.println ("The square root of " + n + " is " + a2);
   }
   
public static Double babSqrt (double a1) 
   {
   
   double nguess = 1, pguess;
   
   do 
   {
   pguess = nguess;
   nguess = (pguess + a1 / pguess) / 2;
   //System.out.println (pguess);
   //System.out.println (nguess);
   } while (Math.abs(nguess - pguess) > 0.00001);

   return nguess;
   }
   
}