/*
This 
is
a
multi-line
comment */

public class Hello //This is a class header
{
   public static void main (String [] args) //Main Method Header
   {
      //code goes here
      System.out.print("1He\nllo");
      System.out.println("\n");
      System.out.println("Welcome \nto \t\t COP 2510" + " Goobert");
   }//end main
  
} //end class