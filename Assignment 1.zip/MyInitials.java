//I pledge my Honor that I have not cheated, and will not cheat, on this assignment Benjamin Allen U30786148
public class MyInitials //This is a class header
{
  public static void main (String[] args) //Main Method Header
  {
      System.out.print("BBBBB    GGG    AAA  \nB   B   G  GG  A   A\n"
                      +"B   B   G      A   A \nB  BB   G      A   A\n"
                      +"BBB     G      AAAAA \nB  BB   G  GG  A   A\n"
                      +"B   B   G   G  A   A \nB   B   G   G  A   A\n"
                      +"BBBBB    GGG   A   A");  
                      //Outputs BGA under specified constrainsts
  }
} 
                      