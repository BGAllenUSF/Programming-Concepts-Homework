//I pledge my Honor that I have not cheated, and will not cheat, on this assignment Benjamin Allen U30786148

public class FactsRev
{

   public static void main(String[] args)
   {
   
// Strings can be concatenated into one long string
   
System.out.println("We present the following facts for your "
+ "extracurricular edification:");
   
System.out.println();

// A string can contain numeric digits

System.out.println("**************************************\n"
                  +"*Letters in the Hawaiian alphabet: 12*\n"
                  +"**************************************");
                  
System.out.println();//seperates facts


System.out.println("##################################\n"
                  +"#Dialing code for Antarctica: " + 672 + "#\n"
                  +"##################################");
                  
System.out.println();

System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
                  +"+Year in which Leonardo da Vinci invented "
                  + "the parachute: " + 1515 + "+\n"
                  +"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
              
System.out.println();

System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n"
                  +"^Speed of ketchup: " + 40 + " km per year^\n"
                  +"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
}
}